create PROCEDURE jc(n INT, o OUT INT)
IS
  i INT;
  result_ INT := 1;
BEGIN
  FOR i IN 1..n LOOP
    result_ := result_ * i;
  END LOOP;
  /

