create procedure  zz (zhuan number,id number) as
	yue zh.zye%TYPE；
BEGIN
	yue := SELECT zye from zh where zid=id;
	if yue>=zhuan then
		update zh set zye = yue-zhuan;
		insert into jy(jid,jdate,zid,jlb,jje) values(1,sysdate,id,'支出',zhuan);
		dbms_output.put_line('转账成功');
	else
		dbms_output.put_line('余额不足');
	end if;
    /

