create package body pck
is
     function a return int
     is
     begin
          dbms_output.put_line('这是a函数');
          return 1;
     end; /

