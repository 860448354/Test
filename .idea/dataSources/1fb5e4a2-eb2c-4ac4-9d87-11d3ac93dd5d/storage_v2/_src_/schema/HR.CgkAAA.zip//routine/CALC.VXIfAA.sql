create procedure calc(a number default 10,b number,c out number) 
is
	--局部变量
	--c number;
	d number := SELECT zye from zh where zid=1;
begin
	c := a + b; --把结果存入c，当程序调用时，取c的结果就是返回值
	--dbms_output.put_line(c);

end;
/

